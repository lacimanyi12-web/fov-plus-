#pragma once
#include "custom-types/shared/macros.hpp"
#include "UnityEngine/MonoBehaviour.hpp"

// A tiny MonoBehaviour that re-applies the FOV twice a second, because
// cameras (casting / replay / MRC) can be created and destroyed at any time.
DECLARE_CLASS_CODEGEN(FovPlus, FovApplier, UnityEngine::MonoBehaviour,
    DECLARE_INSTANCE_METHOD(void, Update);
    DECLARE_DEFAULT_CTOR();
    public:
    float timer = 0.0f;
)

namespace FovPlus {
    void ApplyNow();     // apply config to all matching active cameras
    void DumpCameras();  // log every active camera so you can build a nameFilter
}
