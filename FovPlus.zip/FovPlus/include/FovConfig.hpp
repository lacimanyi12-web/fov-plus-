#pragma once
#include <string>

namespace FovPlus {
    struct Config {
        bool enabled = true;
        float fov = 90.0f;          // Unity Camera.fieldOfView is VERTICAL degrees, 30-130
        std::string nameFilter;     // comma-separated, case-insensitive substrings; empty = all non-HMD cameras
    };

    Config& GetConfig();
    void LoadConfig();
    void SaveConfig();
}
