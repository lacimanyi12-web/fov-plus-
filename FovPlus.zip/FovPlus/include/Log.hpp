#pragma once
#include "paper2_scotland2/shared/logger.hpp"

#ifndef MOD_ID
#define MOD_ID "FovPlus"
#endif
#ifndef VERSION
#define VERSION "0.1.0"
#endif

namespace FovPlus {
    // NOTE: the exact logger type/macro the template uses may differ slightly.
    // If your generated template defines its own logger, use that instead.
    inline constexpr auto Logger = Paper::ConstLoggerContext(MOD_ID);
}
