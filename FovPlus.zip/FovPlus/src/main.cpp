// FovPlus - spectator/cast camera FOV for Beat Saber Quest (1.40.8_7379).
//
// IMPORTANT: keep the template's own setup()/load boilerplate if it differs from
// what is below; the template is the source of truth for the modloader entry points.

#include "scotland2/shared/modloader.h"
#include "beatsaber-hook/shared/utils/hooking.hpp"
#include "beatsaber-hook/shared/utils/il2cpp-functions.hpp"
#include "custom-types/shared/register.hpp"
#include "bsml/shared/BSML.hpp"

#include "UnityEngine/GameObject.hpp"
#include "UnityEngine/Object.hpp"
#include "HMUI/ViewController.hpp"
#include "GlobalNamespace/MainMenuViewController.hpp"

#include "Log.hpp"
#include "FovConfig.hpp"
#include "FovApplier.hpp"

using FovPlus::Logger;

static modloader::ModInfo modInfo{MOD_ID, VERSION, 0};

// ---------------------------------------------------------------- hook
// Spawn the applier once the main menu shows up (Unity is definitely running by then).
MAKE_HOOK_MATCH(MainMenu_DidActivate,
                &GlobalNamespace::MainMenuViewController::DidActivate,
                void,
                GlobalNamespace::MainMenuViewController* self,
                bool firstActivation, bool addedToHierarchy, bool screenSystemEnabling) {
    MainMenu_DidActivate(self, firstActivation, addedToHierarchy, screenSystemEnabling);

    static bool created = false;
    if (!created) {
        created = true;
        auto go = UnityEngine::GameObject::New_ctor("FovPlusApplier");
        UnityEngine::Object::DontDestroyOnLoad(go);
        go->AddComponent<FovPlus::FovApplier*>();
        Logger.info("FovApplier created");
    }
}

// ---------------------------------------------------------------- UI
static void SettingsDidActivate(HMUI::ViewController* self, bool firstActivation, bool, bool) {
    if (!firstActivation) return;
    auto& cfg = FovPlus::GetConfig();

    auto container = BSML::Lite::CreateScrollableSettingsContainer(self->get_transform());
    auto parent = container->get_transform();

    BSML::Lite::CreateText(parent, "FovPlus");
    BSML::Lite::CreateText(parent,
        "Changes the FOV of spectator / casting / capture cameras only. "
        "The headset's own FOV is set by the Quest runtime and is not changed.");

    BSML::Lite::CreateToggle(parent, "Enabled", cfg.enabled, [](bool v) {
        FovPlus::GetConfig().enabled = v;
        FovPlus::SaveConfig();
        FovPlus::ApplyNow();
    });

    BSML::Lite::CreateSliderSetting(parent, "Camera FOV (degrees)", 1.0f, cfg.fov, 30.0f, 130.0f,
        [](float v) {
            FovPlus::GetConfig().fov = v;
            FovPlus::SaveConfig();
            FovPlus::ApplyNow();
        });

    BSML::Lite::CreateUIButton(parent, "Log cameras to logcat", []() {
        FovPlus::DumpCameras();
    });
}

// ---------------------------------------------------------------- entry points
MOD_EXTERN_FUNC void setup(CModInfo* info) noexcept {
    *info = modInfo.to_c();
    Paper::Logger::RegisterFileContextId(MOD_ID);
    FovPlus::LoadConfig();
}

MOD_EXTERN_FUNC void late_load() noexcept {
    il2cpp_functions::Init();
    custom_types::Register::AutoRegister();

    BSML::Init();
    BSML::Register::RegisterMainMenuViewControllerMethod(
        "FovPlus", "FovPlus", "Spectator camera FOV", SettingsDidActivate);

    INSTALL_HOOK(Logger, MainMenu_DidActivate);
}
