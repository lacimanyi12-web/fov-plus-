#include "FovApplier.hpp"
#include "FovConfig.hpp"
#include "Log.hpp"

#include "beatsaber-hook/shared/utils/typedefs.h"
#include "UnityEngine/Camera.hpp"
#include "UnityEngine/StereoTargetEyeMask.hpp"
#include "UnityEngine/Time.hpp"

#include <algorithm>
#include <cctype>
#include <sstream>

DEFINE_TYPE(FovPlus, FovApplier);

namespace {
    std::string Lower(std::string s) {
        std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
        return s;
    }

    bool Contains(const std::string& hay, const std::string& needle) {
        return Lower(hay).find(Lower(needle)) != std::string::npos;
    }

    bool MatchesFilter(const std::string& camName, const std::string& filter) {
        // Never touch mirror cameras: the game drives their projection itself.
        if (Contains(camName, "mirror")) return false;
        if (filter.empty()) return true;
        std::stringstream ss(filter);
        std::string token;
        while (std::getline(ss, token, ',')) {
            if (!token.empty() && Contains(camName, token)) return true;
        }
        return false;
    }

    template <typename F>
    void ForEachActiveCamera(F&& f) {
        int n = UnityEngine::Camera::get_allCamerasCount();
        if (n <= 0) return;
        ArrayW<UnityEngine::Camera*> cams(n);
        UnityEngine::Camera::GetAllCameras(cams);
        for (auto cam : cams) {
            if (cam) f(cam);
        }
    }

    // The headset camera is driven by the XR runtime. We never touch it.
    bool IsHmdCamera(UnityEngine::Camera* cam) {
        return cam->get_stereoTargetEye() != UnityEngine::StereoTargetEyeMask::None;
    }
}

namespace FovPlus {
    void ApplyNow() {
        auto& cfg = GetConfig();
        if (!cfg.enabled) return;
        ForEachActiveCamera([&](UnityEngine::Camera* cam) {
            if (IsHmdCamera(cam)) return;
            std::string name = static_cast<std::string>(cam->get_name());
            if (!MatchesFilter(name, cfg.nameFilter)) return;
            if (cam->get_fieldOfView() != cfg.fov) cam->set_fieldOfView(cfg.fov);
        });
    }

    void DumpCameras() {
        Logger.info("---- FovPlus camera dump ----");
        ForEachActiveCamera([&](UnityEngine::Camera* cam) {
            Logger.info("camera '{}' hmd={} fov={} hasTargetTexture={}",
                        static_cast<std::string>(cam->get_name()),
                        IsHmdCamera(cam),
                        cam->get_fieldOfView(),
                        cam->get_targetTexture() != nullptr);
        });
        Logger.info("---- end dump ----");
    }

    void FovApplier::Update() {
        timer += UnityEngine::Time::get_unscaledDeltaTime();
        if (timer < 0.5f) return;
        timer = 0.0f;
        ApplyNow();
    }
}
