#include "FovConfig.hpp"
#include "Log.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>

namespace FovPlus {
    // Plain key=value file. Deliberately no JSON/config library, so there is nothing to mis-version.
    static const char* kDir  = "/sdcard/ModData/com.beatgames.beatsaber/Configs";
    static const char* kPath = "/sdcard/ModData/com.beatgames.beatsaber/Configs/FovPlus.cfg";

    Config& GetConfig() {
        static Config cfg;
        return cfg;
    }

    void LoadConfig() {
        auto& cfg = GetConfig();
        std::ifstream in(kPath);
        if (!in) return; // first run: defaults
        std::string line;
        while (std::getline(in, line)) {
            auto eq = line.find('=');
            if (eq == std::string::npos) continue;
            std::string key = line.substr(0, eq), val = line.substr(eq + 1);
            try {
                if (key == "enabled") cfg.enabled = (val == "1");
                else if (key == "fov") cfg.fov = std::clamp(std::stof(val), 30.0f, 130.0f);
                else if (key == "nameFilter") cfg.nameFilter = val;
            } catch (...) { /* ignore malformed line */ }
        }
    }

    void SaveConfig() {
        std::error_code ec;
        std::filesystem::create_directories(kDir, ec);
        std::ofstream out(kPath, std::ios::trunc);
        if (!out) { Logger.error("Could not write {}", kPath); return; }
        auto& cfg = GetConfig();
        out << "enabled=" << (cfg.enabled ? 1 : 0) << "\n"
            << "fov=" << cfg.fov << "\n"
            << "nameFilter=" << cfg.nameFilter << "\n";
    }
}
